package com.example.parentalcontrolchild

// Placeholder main activity. Replace with real code in Android Studio.
